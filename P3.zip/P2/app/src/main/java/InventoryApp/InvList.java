package InventoryApp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.example.p2.R;

import java.util.List;

class InvList extends AppCompatActivity {

    private static final String TAG = "InventoryList";

    private List<Item> mItemList;

    Database inventoryDatabase;

    RecyclerView itemListView;
    TextView emptyListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        setContentView(R.layout.database);

        inventoryDatabase = Database.getInstance(getApplicationContext());
        mItemList = inventoryDatabase.getItems();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        itemListView = findViewById(R.id.itemListView);
        itemListView.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(itemListView.getContext(),
                layoutManager.getOrientation());
        itemListView.addItemDecoration(dividerItemDecoration);

        emptyListView = findViewById(R.id.emptyListView);

        Adapter adapter = new Adapter(mItemList, this, inventoryDatabase);
        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                checkListIsEmpty();
            }
        });

        itemListView.setAdapter(adapter);
        checkListIsEmpty();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.action_add_item:
                Log.d(TAG, "New item view");
                intent = new Intent(getApplicationContext(), Edit.class);
                startActivity(intent);
                return true;

            case R.id.action_toggle_notifications:
                Log.d(TAG, "SMS Notifications view");
                intent = new Intent(getApplicationContext(), SMSnotifications.class);
                startActivity(intent);
                return true;

            case R.id.action_logout:
                Log.d(TAG, "Logging out");
                intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void checkListIsEmpty() {
        Log.d(TAG, "Inventory size: " + mItemList.size());
        if (mItemList.isEmpty()) {
            itemListView.setVisibility(View.GONE);
            emptyListView.setVisibility(View.VISIBLE);
        } else {
            itemListView.setVisibility(View.VISIBLE);
            emptyListView.setVisibility(View.GONE);
        }
    }
}