package InventoryApp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.example.p2.R;

public class SMSnotifications extends AppCompatActivity {

    private static final String TAG = "SMSNotifications";
    public static String PREFERENCE_RECEIVE_NOTIFICATIONS = "pref_receive_notifications";
    private final int REQUEST_SEND_SMS_CODE = 0;
    SwitchMaterial notificationsToggle;
    SharedPreferences sharedPrefs;
    boolean receiveNotifications = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.activity_notifications);

        notificationsToggle = findViewById(R.id.toggle);

        notificationsToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            receiveNotifications = isChecked;
            if (isChecked && hasPermissions()) {
                Log.d(TAG, "Wish to receive notifications");
                notificationsToggle.setChecked(true);
            } else {
                Log.d(TAG, "Does not wish to receive notifications");
                notificationsToggle.setChecked(false);
                receiveNotifications = false;
            }
            savePreferences();
        });

        sharedPrefs = getSharedPreferences(
                "my.app.packagename_preferences", SMSnotifications.MODE_PRIVATE);
        receiveNotifications = sharedPrefs.getBoolean(PREFERENCE_RECEIVE_NOTIFICATIONS, false);

        if (receiveNotifications
                && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED
        ) {
            notificationsToggle.setChecked(true);
        }
    }

    private boolean hasPermissions() {
        String smsPermission = Manifest.permission.SEND_SMS;

        if (ContextCompat.checkSelfPermission(this, smsPermission)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, smsPermission)) {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.sms_notification_title)
                        .setMessage(R.string.SMS_description)
                        .setPositiveButton("OK", (dialog, which) -> ActivityCompat.requestPermissions(
                                SMSnotifications.this,
                                new String[]{smsPermission},
                                REQUEST_SEND_SMS_CODE
                        ))
                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                        .create()
                        .show();
            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{smsPermission},
                        REQUEST_SEND_SMS_CODE
                );
            }
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SEND_SMS_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Successful");
                receiveNotifications = true;
                notificationsToggle.setChecked(true);
            } else {
                Log.d(TAG, "Denied");
                receiveNotifications = false;
                notificationsToggle.setChecked(false);
            }

            savePreferences();
        }
    }

    private void savePreferences() {
        SharedPreferences.Editor editor = sharedPrefs.edit();
        editor.putBoolean(PREFERENCE_RECEIVE_NOTIFICATIONS, receiveNotifications);
        editor.apply();
    }
}